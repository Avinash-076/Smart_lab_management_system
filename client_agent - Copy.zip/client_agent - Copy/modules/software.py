import winreg


def get_installed_software():
    software_list = []

    registry_paths = [
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    ]

    for path in registry_paths:
        try:
            registry = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path)

            count = winreg.QueryInfoKey(registry)[0]

            for i in range(count):
                try:
                    subkey_name = winreg.EnumKey(registry, i)
                    subkey = winreg.OpenKey(registry, subkey_name)

                    try:
                        name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                    except FileNotFoundError:
                        continue

                    try:
                        version = winreg.QueryValueEx(subkey, "DisplayVersion")[0]
                    except FileNotFoundError:
                        version = "Unknown"

                    software_list.append({
                        "name": name,
                        "version": version
                    })

                except Exception:
                    continue

        except Exception:
            continue

    software_list.sort(key=lambda x: x["name"].lower())

    return software_list