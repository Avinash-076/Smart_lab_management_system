import { useState } from 'react'
import Sidebar from './Sidebar.jsx'
import './Layout.css'

const Layout = ({ children }) => {
  const [isExpanded, setIsExpanded] = useState(true)

  const toggleSidebar = () => {
    setIsExpanded(!isExpanded)
  }

  return (
    <div className="layout">
      <Sidebar isExpanded={isExpanded} toggleSidebar={toggleSidebar} />
      <main className={`main-content ${isExpanded ? 'expanded' : 'collapsed'}`}>
        {children}
      </main>
    </div>
  )
}

export default Layout