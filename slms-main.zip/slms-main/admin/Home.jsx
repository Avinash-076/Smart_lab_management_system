import { useState, useEffect } from 'react'

function Home() {
  const [computers, setComputers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = () => {
      fetch('http://YOUR_SERVER_IP:5000/api/all-computers')
        .then(response => response.json())
        .then(data => {
          setComputers(data)
          setLoading(false)
        })
        .catch(err => console.error('Failed to fetch:', err))
    }

    fetchData()                              // run once immediately
    const interval = setInterval(fetchData, 5000)  // then every 5 seconds

    return () => clearInterval(interval)      // cleanup when leaving page
  }, [])

  if (loading) return <p>Loading lab data...</p>

  return (
    <div>
      <h1>Lab Overview</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
        {computers.map((pc) => (
          <div
            key={pc.computer_name}
            style={{ border: '1px solid #ccc', borderRadius: '8px', padding: '16px', width: '220px' }}
          >
            <h3>{pc.computer_name}</h3>
            <p>CPU: {pc.cpu_percent}%</p>
            <p>RAM: {pc.ram_percent}%</p>
            <p>Disk: {pc.disk_percent}%</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Home