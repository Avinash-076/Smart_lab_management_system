import React from 'react'
import DashboardIcon from '@mui/icons-material/Dashboard';
import DvrIcon from '@mui/icons-material/Dvr';
import BugReportIcon from '@mui/icons-material/BugReport';
import InstallDesktopIcon from '@mui/icons-material/InstallDesktop';
import MonitorHeartIcon from '@mui/icons-material/MonitorHeart';
import AppsIcon from '@mui/icons-material/Apps';
import AddAlertIcon from '@mui/icons-material/AddAlert';
import VideogameAssetSharpIcon from '@mui/icons-material/VideogameAssetSharp';
export const sidebarData = [

   {
        title: "Dashboard",
        icon: <DashboardIcon/>,
        link: "/Dashboard"
    },
    {
        title: "computer list",
        icon: <DvrIcon/>,
        link: "/computer list"
    },
    {
        title: "issues raised",
        icon: <BugReportIcon/>,
        link: "/issues-raised"
    },
    {
        title: "installed software",
        icon: <InstallDesktopIcon/>,
        link: "/installed software"
    },
    {
        title: "system monitor",
        icon: <MonitorHeartIcon/>,
        link: "/system monitor"
    },
    {
        title: "running apps",
        icon: <AppsIcon/>,
        link: "/running apps"
    },  
    {
        title: "alerts",
        icon: <AddAlertIcon/>,
        link: "/alerts"
    
    },
        {
        title: "remote commands",
        icon: <VideogameAssetSharpIcon/>,
        link: "/remote commands"
    
    },
]