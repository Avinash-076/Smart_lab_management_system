import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from './Sidebar.jsx'
import Layout from './Layout.jsx'
import './App.css'

function App() {
  return (
    <BrowserRouter>
    <Layout>
          <Routes>
            <Route path="/" element={<Navigate to="/Dashboard" replace />} />
            <Route path="/Dashboard" element={<h1>Dashboard</h1>} />
            <Route path="/computer list" element={<h1>computer list</h1>} />
            <Route path="/issues-raised" element={<h1>Issues Raised</h1>} />
            <Route path="/installed software" element={<h1>Installed software</h1>} />
            <Route path="/system monitor" element={<h1>System monitoring</h1>} />
            <Route path="/running apps" element={<h1>Running apps</h1>} />
            <Route path="/alerts" element={<h1>Alerts</h1>} />
             <Route path="/remote commands" element={<h1>Remote commands</h1>} />
          </Routes>
    </Layout>
    </BrowserRouter>
  )
}

export default App