import './Sidebar.css'
import { sidebarData } from './sidebarData'
import { NavLink } from 'react-router-dom'
import MenuIcon from '@mui/icons-material/Menu'
import GroupsIcon from '@mui/icons-material/Groups';
const Sidebar = ({ isExpanded, toggleSidebar }) => {
  return (
    <div className={`sidebar ${isExpanded ? 'expanded' : 'collapsed'}`}>
      <div className="sidebar-header">
        {isExpanded && <h2 className="title-box"><GroupsIcon/>SLMS</h2>}
        <button className="hamburger-btn" onClick={toggleSidebar}>
          <MenuIcon />
        </button>
      </div>

      <div className="sidebar-links">
        {sidebarData.map((item, index) => (
          <NavLink
            to={item.link}
            key={index}
            className={({ isActive }) => `sidebar-item ${isActive ? 'active' : ''}`}
          >
            {item.icon}
            {isExpanded && <span>{item.title}</span>}
          </NavLink>
        ))}
      </div>
    </div>
  )
}

export default Sidebar