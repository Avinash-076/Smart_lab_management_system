function Sidebar(){

    return(
        <div>

            <h3>
                Menu
            </h3>


            <p>
                Dashboard
            </p>


            <p>
                Computer List
            </p>


            <p>
                System Monitor
            </p>


            <p>
                Settings
            </p>


        </div>
    );

}

export default Sidebar;