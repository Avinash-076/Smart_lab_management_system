function Navbar(){

    return(
        <div>

            <h2>
                SLMS - Lab Monitoring System
            </h2>

            <p>
                Admin
            </p>

        </div>
    );

}

export default Navbar;