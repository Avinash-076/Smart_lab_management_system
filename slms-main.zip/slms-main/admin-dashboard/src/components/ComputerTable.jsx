function ComputerTable(){

    return(
        <table border="1">

             <thead>
                <tr>
                    <th>Computer Name</th>
                    <th>IP Address</th>
                    <th>OS</th>
                    <th>CPU</th>
                    <th>RAM</th>
                    <th>Disk</th>
                    <th>Last Seen</th>
                    <th>Status</th>
                </tr>
            </thead>


            <tbody>

                <tr>
                    <td>LAB-PC-01</td>
                    <td>192.168.1.10</td>
                    <td>Windows 11</td>
                    <td>40%</td>
                    <td>60%</td>
                    <td>70%</td>
                    <td>2 min ago</td>
                    <td>Online</td>
                </tr>

            </tbody>

        </table>
    );

}

export default ComputerTable;