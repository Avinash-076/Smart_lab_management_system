import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState } from "react";


import ComputerList from "./pages/ComputerList";
import ComputerDetails from "./pages/ComputerDetails";
import AddComputer from "./pages/AddComputer";
import EditComputer from "./pages/EditComputer";



function App(){


  const [computers, setComputers] = useState([


    {
      name:"LAB-PC-01",
      user:"Admin",
      ip:"192.168.1.10",
      os:"Windows 11",
      status:"Online"
    },


    {
      name:"LAB-PC-02",
      user:"Student",
      ip:"192.168.1.11",
      os:"Windows 10",
      status:"Offline"
    }


  ]);





  // Add Computer

  const addComputer = (newComputer)=>{


    setComputers([

      ...computers,

      newComputer

    ]);


  };





  // Delete Computer

  const deleteComputer = (index)=>{


    const updatedComputers = computers.filter(

      (pc,i)=> i !== index

    );


    setComputers(updatedComputers);


  };






  // Update Computer

  const updateComputer = (index, updatedComputer)=>{


    const updatedList = computers.map((pc,i)=>{


      if(i === index){

        return updatedComputer;

      }


      return pc;


    });



    setComputers(updatedList);


  };






  return(


    <BrowserRouter>


      <Routes>



        <Route

          path="/"

          element={

            <ComputerList

              computers={computers}

              deleteComputer={deleteComputer}

              updateComputer={updateComputer}

            />

          }

        />





        <Route

          path="/computer-details"

          element={

            <ComputerDetails />

          }

        />






        <Route

          path="/add-computer"

          element={

            <AddComputer

              addComputer={addComputer}

            />

          }

        />







        <Route

          path="/edit-computer/:index"

          element={

            <EditComputer

              computers={computers}

              updateComputer={updateComputer}

            />

          }

        />




      </Routes>


    </BrowserRouter>


  );


}



export default App;