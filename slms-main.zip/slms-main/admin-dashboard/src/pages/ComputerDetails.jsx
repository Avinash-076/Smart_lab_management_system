import "./ComputerList.css";

function ComputerDetails(){

  return(

    <div className="main">

      <h1>Computer Details</h1>

      <div className="card">

        <h2>LAB-PC-01</h2>

        <br />

        <p><b>User:</b> Admin</p>

        <p><b>IP Address:</b> 192.168.1.10</p>

        <p><b>Operating System:</b> Windows 11</p>

        <p><b>Status:</b> Online</p>

        <p><b>CPU Usage:</b> 45%</p>

        <p><b>RAM Usage:</b> 60%</p>

        <p><b>Storage:</b> 70%</p>

      </div>

    </div>

  );

}

export default ComputerDetails;