import "./ComputerList.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";


function ComputerList({ computers, deleteComputer, updateComputer }) {
  const navigate = useNavigate();

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");


  const filteredComputers = computers.filter((pc) => {

    const matchesSearch = pc.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());


    const matchesStatus =
      statusFilter === "All" || pc.status === statusFilter;


    return matchesSearch && matchesStatus;

  });



  return (

    <div className="container">


      {/* Sidebar */}

      <div className="sidebar">

        <h2>SLMS</h2>


        <div className="menu active">
          🖥 Computer List
        </div>


        <div className="menu">
          📦 Software Inventory
        </div>


        <div className="menu">
          ⚠ Issue Management
        </div>


        <div className="menu">
          📊 System Monitor
        </div>


        <div className="menu">
          ⚙ Settings
        </div>


      </div>




      {/* Main */}

      <div className="main">


        <div className="topbar">


          <div>

            <h1>
              🖥 Computer List
            </h1>


            <p className="page-subtitle">
              Manage and monitor all computers in the laboratory
            </p>


          </div>



          <div>


            <button
              onClick={() => navigate("/add-computer")}
            >

              + Add Computer

            </button>



            <button

              className="refresh-btn"

              onClick={() => window.location.reload()}

            >

              🔄 Refresh

            </button>


          </div>


        </div>





        {/* Status Cards */}


        <div className="stats">


          <div className="stat-card">

            <h3>🖥 Total Computers</h3>

            <p className="count">
              {computers.length}
            </p>

          </div>




          <div className="stat-card">

            <h3>🟢 Online</h3>

            <p className="count green">

              {
                computers.filter(
                  pc => pc.status === "Online"
                ).length
              }

            </p>

          </div>





          <div className="stat-card">

            <h3>🔴 Offline</h3>

            <p className="count red">

              {
                computers.filter(
                  pc => pc.status === "Offline"
                ).length
              }

            </p>

          </div>





          <div className="stat-card">

            <h3>⚠ Issues</h3>

            <p className="count orange">
              0
            </p>

          </div>


        </div>





        {/* Search */}


        <div className="search">


          <input

            type="text"

            placeholder="Search computer..."

            value={searchTerm}

            onChange={(e)=>setSearchTerm(e.target.value)}

          />




          <select

            value={statusFilter}

            onChange={(e)=>setStatusFilter(e.target.value)}

          >

            <option value="All">
              All Status
            </option>


            <option value="Online">
              Online
            </option>


            <option value="Offline">
              Offline
            </option>


          </select>


        </div>






        {/* Table */}


        <div className="card">


          <table>


            <thead>

              <tr>

                <th>
                  Computer Name
                </th>


                <th>
                  User
                </th>


                <th>
                  IP Address
                </th>


                <th>
                  Operating System
                </th>


                <th>
                  Status
                </th>


                <th>
                  Action
                </th>


              </tr>


            </thead>





            <tbody>


              {

                filteredComputers.map((pc,index)=>(


                  <tr key={index}>


                    <td>
                      {pc.name}
                    </td>


                    <td>
                      {pc.user}
                    </td>


                    <td>
                      {pc.ip}
                    </td>


                    <td>
                      {pc.os}
                    </td>



                    <td>

                      <span

                        className={
                          pc.status === "Online"
                          ?
                          "online"
                          :
                          "offline"
                        }

                      >

                        {pc.status}

                      </span>


                    </td>





                   <td>


<button

  className="edit-btn"

  onClick={() =>
    navigate(`/edit-computer/${index}`)
  }

>

  Edit

</button>




  <button

    className="view"

    onClick={() =>
      navigate("/computer-details")
    }

  >

    View

  </button>




  <button

    className="delete-btn"

    onClick={() =>
      deleteComputer(index)
    }

  >

    Delete

  </button>


</td>



                  </tr>


                ))

              }


            </tbody>


          </table>


        </div>



      </div>


    </div>


  );

}


export default ComputerList;