import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";


function EditComputer({ computers, updateComputer }) {


  const navigate = useNavigate();

  const { index } = useParams();



  const oldComputer = computers[index];



  const [computer, setComputer] = useState({

    name: oldComputer.name,

    user: oldComputer.user,

    ip: oldComputer.ip,

    os: oldComputer.os,

    status: oldComputer.status

  });





  const handleChange = (e)=>{


    setComputer({

      ...computer,

      [e.target.name]: e.target.value

    });


  };






  const handleUpdate = ()=>{


    updateComputer(

      Number(index),

      computer

    );


    navigate("/");


  };





  return(


    <div>


      <h1>
        Edit Computer
      </h1>




      <input

        name="name"

        value={computer.name}

        onChange={handleChange}

        placeholder="Computer Name"

      />





      <input

        name="user"

        value={computer.user}

        onChange={handleChange}

        placeholder="User"

      />





      <input

        name="ip"

        value={computer.ip}

        onChange={handleChange}

        placeholder="IP Address"

      />





      <input

        name="os"

        value={computer.os}

        onChange={handleChange}

        placeholder="Operating System"

      />






      <select

        name="status"

        value={computer.status}

        onChange={handleChange}

      >

        <option value="Online">
          Online
        </option>


        <option value="Offline">
          Offline
        </option>


      </select>






      <br/><br/>




      <button

        onClick={handleUpdate}

      >

        Update

      </button>





      <button

        onClick={() => navigate("/")}

      >

        Cancel

      </button>



    </div>


  );

}


export default EditComputer;