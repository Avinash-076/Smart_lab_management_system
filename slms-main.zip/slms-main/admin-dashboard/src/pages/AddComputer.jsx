import "./ComputerList.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";


function AddComputer({ addComputer }){


  const navigate = useNavigate();


  const [computer,setComputer] = useState({

    name:"",
    user:"",
    ip:"",
    os:"Windows 11",
    status:"Online"

  });



  const handleChange = (e)=>{

    setComputer({

      ...computer,

      [e.target.name]: e.target.value

    });

  };



  const saveComputer = ()=>{


    addComputer(computer);


    alert("Computer Added Successfully");


    navigate("/");


  };



  return(


    <div className="main">


      <h1>
        Add New Computer
      </h1>




      <div className="card">



        <label>
          Computer Name
        </label>


        <input

          name="name"

          value={computer.name}

          onChange={handleChange}

          placeholder="Enter computer name"

        />





        <label>
          User Name
        </label>


        <input

          name="user"

          value={computer.user}

          onChange={handleChange}

          placeholder="Enter user name"

        />





        <label>
          IP Address
        </label>


        <input

          name="ip"

          value={computer.ip}

          onChange={handleChange}

          placeholder="Enter IP address"

        />






        <label>
          Operating System
        </label>


        <select

          name="os"

          value={computer.os}

          onChange={handleChange}

        >


          <option>
            Windows 11
          </option>


          <option>
            Windows 10
          </option>


        </select>






        <label>
          Status
        </label>


        <select

          name="status"

          value={computer.status}

          onChange={handleChange}

        >


          <option>
            Online
          </option>


          <option>
            Offline
          </option>


        </select>







        <button

          className="save-btn"

          onClick={saveComputer}

        >

          Save Computer

        </button>




      </div>


    </div>


  );


}


export default AddComputer;